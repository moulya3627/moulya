import java.sql.Statement;

import java.util.ArrayList;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = "/Banking")
public class Banking extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		ArrayList<Integer> trans_list=new ArrayList<Integer>();
		String amount=request.getParameter("amount");
		Connection mycon=null;
		Statement mystmt=null,mystmt1=null,mystmt2=null;
		ResultSet myrs=null,myrs1=null,myrs2=null;
		try {
			mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/Moulya","root","moulya");
			mystmt=mycon.createStatement();
			mystmt1=mycon.createStatement();
			mystmt2=mycon.createStatement();
			
			myrs=mystmt.executeQuery("select balance,acc_id from bank");
			while(myrs.next()) {
				int updatebalance=myrs.getInt("balance");
				int accountid=myrs.getInt("acc_id");
				updatebalance=updatebalance-Integer.parseInt(amount);
				PreparedStatement preparestmt=mycon.prepareStatement("update bank set balance=? where acc_id=?");
				preparestmt.setInt(1,updatebalance);
				preparestmt.setInt(2, accountid);
				preparestmt.executeUpdate();
				myrs2=mystmt1.executeQuery("select count(*) as countlist from transcation");
				while(myrs2.next()) {
				int count=myrs2.getInt("countlist");
				PreparedStatement preparestmt1=mycon.prepareStatement("insert into transcation(serialno,acc_id,amount)values(?,?,?)");
				preparestmt1.setInt(2,accountid);
				preparestmt1.setInt(3, Integer.parseInt(amount));
				preparestmt1.setInt(1, count+1);
				preparestmt1.executeUpdate();
				}
				myrs1=mystmt2.executeQuery("select amount from transcation where serialno>((select count(*) from transcation)-5)");
				while(myrs1.next()) {
					int  trans_amount=myrs1.getInt("amount");
					trans_list.add(trans_amount);
					
				}
				request.setAttribute("transferlist", trans_list);
				request.setAttribute("Availablebalance", updatebalance);
				request.getRequestDispatcher("Banking.jsp").forward(request, response);
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(mycon!=null)
				try {
					mycon.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(mystmt!=null)
				try {
					mystmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(myrs!=null)
				try {
					myrs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		
	}
}
