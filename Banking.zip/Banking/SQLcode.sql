create table bank(acc_id numeric(13) primary key,username varchar(30),balance numeric(10));
insert into bank(acc_id,username,balance) values(1023456789,"Moulya",60000);
select *from balance;
create table transcation(serialno numeric(10),acc_id numeric(13),amount numeric(10),foreign key(acc_id) references bank(acc_id)); 
select *from transcation;
